package com.example;

public class Enemy extends Unit {
    
    public Enemy(String unitName, int unitLevel, int damage, int maxHP, int currentHP, int dexterity, int agility, boolean isPlayer) {
        this.unitName = unitName;
        this.unitLevel = unitLevel;
        this.damage = damage;
        this.maxHP = maxHP;
        this.currentHP = currentHP;
        this.dexterity = dexterity;
        this.agility = agility;
        this.isPlayer = isPlayer;
    }
}
