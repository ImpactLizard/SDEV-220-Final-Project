package com.example;

public abstract class Unit {

    public String unitName;
    public int unitLevel;

    public int damage;

    public int maxHP;
    public int currentHP;
    public int dexterity;
    public int agility;

    public boolean isPlayer;

    public boolean TakeDamage(int damage) {
        currentHP -= damage;

        if (currentHP <= 0)
            return true;
        else
            return false;
    }

    public void Heal(int amount) {
        currentHP += amount;
        
        if (currentHP > maxHP)
            currentHP = maxHP;
    }

    public float GetHealthNormalized() {
        return (float)currentHP / maxHP;
    }
}