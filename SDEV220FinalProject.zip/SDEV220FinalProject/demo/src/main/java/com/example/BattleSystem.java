package com.example;

import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;

public class BattleSystem {

    public Player player;
    public Enemy enemy;

    public String dialogueText;

    public static BattleState battleState = BattleState.Start;
    
    public void SetupBattle() {
        // assign the units for battle
        player = new Player("Adventurer", 1, 7, 20, 20, 4, 5, true);
        enemy = new Enemy("Slime", 3, 10, 25, 25, 1, 1, false);

        dialogueText = "A wild " + enemy.unitName + " appeared.";

        battleState = BattleState.PlayerTurn;
    }
    
    private void PlayerAttack(ProgressBar playerHealth, ProgressBar enemyHealth, Label dialogueText) {
        int damageAmount = 0;
        // Set the dialogue Text
        dialogueText.setText("You Attack!!!");

        // Get a random chance for the hit
        int hitChance = (int)(player.dexterity * 100 / enemy.agility * 2);
        int randomNumber = (int)(Math.random() * 100) + 1;
        if (randomNumber < hitChance) {
            // If it did hit set the damage amount
            damageAmount = player.damage;
            // Set the dialogue Text
            dialogueText.setText("Attack Hit! Gave " + damageAmount + " damage!");
        } else {
            // Else leave at zero
            // Set the dialogue Text
            dialogueText.setText("Attack Missed!");
        }

        // Damage the enemy
        boolean isDead = enemy.TakeDamage(damageAmount);
        enemyHealth.setProgress(enemy.GetHealthNormalized());
        // Change color of units health bar accordingly
        if (enemy.GetHealthNormalized() < 0.2) {
            enemyHealth.setStyle("-fx-accent: red;"); 
        } else if (enemy.GetHealthNormalized() < 0.5) {
            enemyHealth.setStyle("-fx-accent: yellow;"); 
        }

        if (isDead) {
            // If the enemy is dead, end the battle as a victory
            battleState = BattleState.Won;
            
            EndBattle(dialogueText);
        } else {
            // Else pass the turn to the player
            battleState = BattleState.EnemyTurn;
            EnemyTurn(playerHealth, dialogueText);
        }
    }

    private void EnemyTurn(ProgressBar playerHealth, Label dialogueText) {
        int damageAmount = 0;
        // Set the dialogue Text
        dialogueText.setText(enemy.unitName + " attacks!");
        // Get a random chance for the hit
        int hitChance = (int)(enemy.dexterity * 100 / player.agility * 2);
        int randomNumber = (int)(Math.random() * 100) + 1;
        if (randomNumber < hitChance) {
            // If it did hit set the damage amount
            damageAmount = enemy.damage;
            // Set the dialogue Text
            dialogueText.setText("Attack Hit! Gave " + damageAmount + " damage!");
        } else {
            // Else leave it at zero
            // Set the dialogue Text
            dialogueText.setText("Attack Missed!");
        }
        // Damage the player
        boolean isDead = player.TakeDamage(damageAmount);

        // Update the player's health bar
        playerHealth.setProgress(player.GetHealthNormalized());
        // Change color of units health bar accordingly
        if (player.GetHealthNormalized() < 0.2) {
            playerHealth.setStyle("-fx-accent: red;"); 
        } else if (player.GetHealthNormalized() < 0.5) {
            playerHealth.setStyle("-fx-accent: yellow;"); 
        }

        if (isDead) {
            // If the player is dead, end the battle as a loss
            battleState = BattleState.Lost;
            EndBattle(dialogueText);
        } else {
            // Else pass the turn to the enemy
            battleState = BattleState.PlayerTurn;
        }
    }

    private void EndBattle(Label dialogueText) {
        if (battleState == BattleState.Won) {
            // Set the dialogue Text
            dialogueText.setText("You vanquished the " + enemy.unitName + "! You won!");
        } else if (battleState == BattleState.Lost) {
            // Set the dialogue Text
            dialogueText.setText("You were defeated by the " + enemy.unitName + ". You Lost.");
        }
    }

    private void PlayerHeal(ProgressBar playerHealth, Label dialogueText) {
        player.Heal(3);
        // Update the player's health bar
        playerHealth.setProgress(player.GetHealthNormalized());
        if (player.GetHealthNormalized() < 0.2) {
            playerHealth.setStyle("-fx-accent: red;"); 
        } else if (player.GetHealthNormalized() < 0.5) {
            playerHealth.setStyle("-fx-accent: yellow;"); 
        } else {
            playerHealth.setStyle("-fx-accent: green;"); 
        }

        
        // Set the dialogue Text
        dialogueText.setText("You feel renewed strength!");

        // set the battle state to the enemy's turn
        battleState = BattleState.EnemyTurn;
        EnemyTurn(playerHealth, dialogueText);
    }

    public void OnAttackButton(ProgressBar playerHealth, ProgressBar enemyHealth, Label dialogueText) {
        if (battleState != BattleState.PlayerTurn) {
            return;
        }

        PlayerAttack(playerHealth, enemyHealth, dialogueText);
    }

    public void OnHealButton(ProgressBar playerHeath, Label dialogueText) {
        if (battleState != BattleState.PlayerTurn) {
            return;
        }

        PlayerHeal(playerHeath, dialogueText);
    }

    public String GetDialogueText() {
        return dialogueText;
    }

    public Player GetPlayer() {
        return player;
    }

    public Enemy GetEnemy() {
        return enemy;
    }
}
