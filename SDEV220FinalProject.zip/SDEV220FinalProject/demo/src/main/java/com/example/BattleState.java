package com.example;

public enum BattleState {
    Start,
    PlayerTurn,
    EnemyTurn,
    Won,
    Lost
}

