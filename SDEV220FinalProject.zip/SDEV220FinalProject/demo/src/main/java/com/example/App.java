package com.example;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.stage.Stage;
import javafx.scene.shape.Rectangle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * JavaFX App
 */
public class App extends Application {
    
    static Image playerImage;
    static ImageView playerSprite = new ImageView();
    static Image enemyImage;
    static ImageView enemySprite = new ImageView();
    static int playerAttackAnimationIndex = 0;
    static int playerDieAnimationIndex = 0;
    static int enemyAttackAnimationIndex = 0;
    static int enemyDieAnimationIndex = 0;
    static boolean battleOver = false;
    
    @Override
    public void start(Stage stage) throws FileNotFoundException {
        Thread newThread = new Thread();
        newThread.start();
        
        // Create a battle system
        BattleSystem battleSystem = new BattleSystem();
        battleSystem.SetupBattle();
        
        // Player Sprite
        playerImage = new Image(new FileInputStream("Images\\Idle\\adventurer-idle-2-03.png"), 50 * 10, 37 * 10, true, false);
        Image[] playerAttackAnimation = { new Image(new FileInputStream("Images\\Attack\\adventurer-attack1-00.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\adventurer-attack1-01.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\adventurer-attack1-02.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\adventurer-attack1-03.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\adventurer-attack1-04.png"), 50 * 10, 37 * 10, true, false) };
        Image[] playerDieAnimation = { new Image(new FileInputStream("Images\\Die\\adventurer-die-00.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-01.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-02.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-03.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-04.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-05.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\adventurer-die-06.png"), 50 * 10, 37 * 10, true, false) };
        Thread playerDieAnim = new Thread(new Runnable() { 
            @Override
            public void run() {
                try {
                    while (playerDieAnimationIndex < 6) {
                        Platform.runLater(new Runnable() { // Run from JavaFX GUI
                            @Override 
                            public void run() {
                                if (playerDieAnimationIndex == 0)
                                    SetPlayerSprite(playerDieAnimation[0]);
                                if (playerDieAnimationIndex == 1)
                                    SetPlayerSprite(playerDieAnimation[1]);
                                if (playerDieAnimationIndex == 2)
                                    SetPlayerSprite(playerDieAnimation[2]);
                                if (playerDieAnimationIndex == 3)
                                    SetPlayerSprite(playerDieAnimation[3]);
                                if (playerDieAnimationIndex == 4)
                                    SetPlayerSprite(playerDieAnimation[4]);
                                if (playerDieAnimationIndex == 5)
                                    SetPlayerSprite(playerDieAnimation[5]);
                                if (playerDieAnimationIndex == 6)
                                    SetPlayerSprite(playerDieAnimation[6]);
                            }
                        });
            
                        Thread.sleep(200);
                        playerDieAnimationIndex++;
                    }
                }
                catch (InterruptedException ex) {
                }
            }
        });
        SetPlayerSprite(playerImage);
        playerSprite.setX(20);
        playerSprite.setY(117);
        playerSprite.setFitWidth(50 * 5);
        playerSprite.setFitWidth(37 * 5);
        playerSprite.setPreserveRatio(true);
        // Player HUD
        Rectangle playerHUDBackground = new Rectangle();
        playerHUDBackground.setWidth(100);
        playerHUDBackground.setHeight(50);
        playerHUDBackground.setY(20);
        playerHUDBackground.setX(50);
        playerHUDBackground.setFill(Color.WHITE);
        playerHUDBackground.setStroke(Color.BLACK);
        playerHUDBackground.setArcWidth(30);
        playerHUDBackground.setArcHeight(30);
        // Player name
        Label playerName = new Label(battleSystem.GetPlayer().unitName);
        playerName.setLayoutX(55);
        playerName.setLayoutY(25);
        // Player level
        Label playerLevel = new Label("Lvl " + battleSystem.GetPlayer().unitLevel);
        playerLevel.setLayoutX(120);
        playerLevel.setLayoutY(25);
        // Player health bar
        ProgressBar playerHealth = new ProgressBar(1);
        playerHealth.setPrefSize(90, 10);
        playerHealth.setLayoutX(55);
        playerHealth.setLayoutY(48);
        playerHealth.setStyle("-fx-accent: green;"); 
        
        // Enemy Sprite
        enemyImage = new Image(new FileInputStream("Images\\Idle\\slime-idle-0.png"), 32 * 10, 25 * 10, true, false);
        Image[] enemyAttackAnimation = { new Image(new FileInputStream("Images\\Attack\\slime-attack-0.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\slime-attack-1.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\slime-attack-2.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\slime-attack-3.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Attack\\slime-attack-4.png"), 50 * 10, 37 * 10, true, false) };
        Image[] enemyDieAnimation = { new Image(new FileInputStream("Images\\Die\\slime-die-0.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\slime-die-1.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\slime-die-2.png"), 50 * 10, 37 * 10, true, false), new Image(new FileInputStream("Images\\Die\\slime-die-3.png"), 50 * 10, 37 * 10, true, false) };
        Thread enemyDieAnim = new Thread(new Runnable() { 
            @Override
            public void run() {
                try {
                    while (enemyAttackAnimationIndex < 3) {
                        Platform.runLater(new Runnable() { // Run from JavaFX GUI
                        @Override 
                            public void run() {
                                if (enemyDieAnimationIndex == 0)
                                    SetEnemySprite(enemyDieAnimation[0]);
                                if (enemyDieAnimationIndex == 1)
                                    SetEnemySprite(enemyDieAnimation[1]);
                                if (enemyDieAnimationIndex == 2)
                                    SetEnemySprite(enemyDieAnimation[2]);
                                    if (enemyDieAnimationIndex == 3)
                                    SetEnemySprite(enemyDieAnimation[3]);
                            }
                        });
            
                        Thread.sleep(200);
                        enemyAttackAnimationIndex++;
                    }
                }
                catch (InterruptedException ex) {
                }
            }
        });
        SetEnemySprite(enemyImage);
        enemySprite.setX(450);
        enemySprite.setY(175);
        enemySprite.setFitWidth(32 * 4);
        enemySprite.setFitWidth(25 * 4);
        enemySprite.setPreserveRatio(true);
        // Enemy HUD
        Rectangle enemyHUDBackground = new Rectangle();
        enemyHUDBackground.setWidth(100);
        enemyHUDBackground.setHeight(50);
        enemyHUDBackground.setY(20);
        enemyHUDBackground.setX(450);
        enemyHUDBackground.setFill(Color.WHITE);
        enemyHUDBackground.setStroke(Color.BLACK);
        enemyHUDBackground.setArcWidth(30);
        enemyHUDBackground.setArcHeight(30);

        // Enemy name
        Label enemyName = new Label(battleSystem.GetEnemy().unitName);
        enemyName.setLayoutX(455);
        enemyName.setLayoutY(25);
        // Enemy level
        Label enemyLevel = new Label("Lvl " + battleSystem.GetEnemy().unitLevel);
        enemyLevel.setLayoutX(515);
        enemyLevel.setLayoutY(25);
        // Enemy health bar
        ProgressBar enemyHealth = new ProgressBar(1);
        enemyHealth.setPrefSize(90, 10);
        enemyHealth.setLayoutX(455);
        enemyHealth.setLayoutY(48);
        enemyHealth.setStyle("-fx-accent: green;"); 

        // Menu Background
        Rectangle dirt = new Rectangle();
        dirt.setWidth(600);
        dirt.setHeight(400);
        dirt.setY(250);
        dirt.setX(0);
        dirt.setFill(Color.rgb(129, 84, 52));

        // Menu Background
        Rectangle grass = new Rectangle();
        grass.setWidth(600);
        grass.setHeight(30);
        grass.setY(250);
        grass.setX(0);
        grass.setFill(Color.rgb(98, 118, 40));


        // Dialogue Text
        Label dialogueText = new Label(battleSystem.GetDialogueText());
        dialogueText.setLayoutX(50);
        dialogueText.setLayoutY(315);
        dialogueText.setTextFill(Color.WHITE);
        
        // Attack Button
        Button attackBtn = new Button("Attack");
        attackBtn.setLayoutX(500);
        attackBtn.setLayoutY(315);
        EventHandler<ActionEvent> attackEvent = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                Thread enemyAttackAnim = new Thread(new Runnable() { 
                    @Override
                    public void run() {
                        try {
                            while (enemyAttackAnimationIndex < 4) {
                                Platform.runLater(new Runnable() { // Run from JavaFX GUI
                                @Override 
                                public void run() {
                                        if (enemyAttackAnimationIndex == 0)
                                        SetEnemySprite(enemyAttackAnimation[0]);
                                        if (enemyAttackAnimationIndex == 1)
                                            SetEnemySprite(enemyAttackAnimation[1]);
                                        if (enemyAttackAnimationIndex == 2)
                                            SetEnemySprite(enemyAttackAnimation[2]);
                                        if (enemyAttackAnimationIndex == 3)
                                            SetEnemySprite(enemyAttackAnimation[3]);
                                        if (enemyAttackAnimationIndex == 4)
                                            SetEnemySprite(enemyAttackAnimation[4]);
                                        }
                                });
                    
                                Thread.sleep(200);
                                enemyAttackAnimationIndex++;
                            }
                            enemyAttackAnimationIndex = 0;
                            SetEnemySprite(enemyImage);
                        }
                        catch (InterruptedException ex) {
                        }
                    }
                });
                battleSystem.OnAttackButton(playerHealth, enemyHealth, dialogueText);
                if (!battleOver) {
                    new Thread(new Runnable() { 
                        @Override
                        public void run() {
                            try {
                                while (playerAttackAnimationIndex < 4 && BattleSystem.battleState == BattleState.PlayerTurn) {
                                    Platform.runLater(new Runnable() { // Run from JavaFX GUI
                                        @Override 
                                        public void run() {
                                            if (playerAttackAnimationIndex == 0)
                                                SetPlayerSprite(playerAttackAnimation[0]);
                                            if (playerAttackAnimationIndex == 1)
                                                SetPlayerSprite(playerAttackAnimation[1]);
                                            if (playerAttackAnimationIndex == 2)
                                                SetPlayerSprite(playerAttackAnimation[2]);
                                            if (playerAttackAnimationIndex == 3)
                                                SetPlayerSprite(playerAttackAnimation[3]);
                                                if (playerAttackAnimationIndex == 4)
                                                SetPlayerSprite(playerAttackAnimation[4]);
                                            }
                                        });
                        
                                    Thread.sleep(200);
                                    playerAttackAnimationIndex++;
                                }
                                playerAttackAnimationIndex = 0;
                                try {
                                    if (BattleSystem.battleState == BattleState.Won) {
                                        enemyDieAnim.start();
                                        battleOver = true;
                                    } else if (BattleSystem.battleState == BattleState.Lost) {
                                        playerDieAnim.start();
                                        battleOver = true;
                                    } else {
                                        enemyAttackAnim.start();
                                    }
                                } catch (IllegalThreadStateException exception) {
                                }
                                SetPlayerSprite(playerImage);
                            }
                            catch (InterruptedException ex) {
                            }
                        }
                    }).start();
                }
            }
        };
        attackBtn.setOnAction(attackEvent);

        // Heal Button
        Button healBtn = new Button("Heal");
        healBtn.setLayoutX(550);
        healBtn.setLayoutY(315);
        EventHandler<ActionEvent> healEvent = new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                Thread enemyAttackAnim = new Thread(new Runnable() { 
                    @Override
                    public void run() {
                        try {
                            while (enemyAttackAnimationIndex < 4) {
                                Platform.runLater(new Runnable() { // Run from JavaFX GUI
                                @Override 
                                public void run() {
                                        if (enemyAttackAnimationIndex == 0)
                                        SetEnemySprite(enemyAttackAnimation[0]);
                                        if (enemyAttackAnimationIndex == 1)
                                            SetEnemySprite(enemyAttackAnimation[1]);
                                        if (enemyAttackAnimationIndex == 2)
                                            SetEnemySprite(enemyAttackAnimation[2]);
                                        if (enemyAttackAnimationIndex == 3)
                                            SetEnemySprite(enemyAttackAnimation[3]);
                                        if (enemyAttackAnimationIndex == 4)
                                            SetEnemySprite(enemyAttackAnimation[4]);
                                        }
                                });
                    
                                Thread.sleep(200);
                                enemyAttackAnimationIndex++;
                            }
                            enemyAttackAnimationIndex = 0;
                            SetEnemySprite(enemyImage);
                        }
                        catch (InterruptedException ex) {
                        }
                    }
                });
                battleSystem.OnHealButton(playerHealth, dialogueText);
                if (!battleOver) {
                    try {
                        if (BattleSystem.battleState == BattleState.Lost) {
                            playerDieAnim.start();
                            battleOver = true;
                        } else {
                            enemyAttackAnim.start();
                        }
                    } catch (IllegalThreadStateException exception) {
                    };
                }
            }
        };
        healBtn.setOnAction(healEvent);


        // Create background color
        Stop[] stops = new Stop[] {
            new Stop(0, Color.rgb(255, 209, 90)),
            new Stop(1, Color.rgb(255, 109, 71))
        };
        LinearGradient backgroundColor = new LinearGradient(0, 1, 0, 0, true, CycleMethod.REFLECT, stops);

        // Create Scene
        Group root = new Group(playerHUDBackground, playerName, playerLevel, playerHealth, enemyHUDBackground, enemyName, enemyLevel, enemyHealth, dirt, grass, dialogueText, attackBtn, healBtn, playerSprite, enemySprite);
        Scene scene = new Scene(root, 600, 350, backgroundColor);
        stage.setTitle("Simple Battle System");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    public static void SetPlayerSprite(Image image) {
        playerSprite.setImage(image);
    }
    
    public static void SetEnemySprite(Image image) {
        enemySprite.setImage(image);
    }
}